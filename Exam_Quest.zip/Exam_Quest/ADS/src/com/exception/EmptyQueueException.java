package com.exception;

public class EmptyQueueException extends Exception {

	public EmptyQueueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
