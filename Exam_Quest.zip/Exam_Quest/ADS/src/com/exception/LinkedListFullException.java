package com.exception;

public class LinkedListFullException extends Exception {

	public LinkedListFullException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
