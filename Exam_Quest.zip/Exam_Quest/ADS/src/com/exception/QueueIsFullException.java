package com.exception;

public class QueueIsFullException extends Exception {

	public QueueIsFullException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
