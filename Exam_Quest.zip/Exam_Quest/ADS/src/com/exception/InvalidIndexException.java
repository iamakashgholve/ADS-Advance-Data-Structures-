package com.exception;

public class InvalidIndexException extends Exception {

	public InvalidIndexException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
