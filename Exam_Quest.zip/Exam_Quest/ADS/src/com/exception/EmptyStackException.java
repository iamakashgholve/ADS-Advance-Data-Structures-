package com.exception;

public class EmptyStackException extends Exception {

	public EmptyStackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
