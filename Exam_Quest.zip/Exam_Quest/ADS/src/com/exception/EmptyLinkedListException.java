package com.exception;

public class EmptyLinkedListException extends Exception {
	
	public EmptyLinkedListException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
