package com.exception;

public class EmptyListException extends Exception {

	public EmptyListException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
